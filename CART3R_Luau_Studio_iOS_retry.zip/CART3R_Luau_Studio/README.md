# CART3R Luau Studio

A lightweight, mobile-friendly Luau source editor for iPhone and iPad.

## Included
- `index.html` — standalone editor; no build tools or external libraries required.
- `LICENSE` — separate MIT license.

## Use on iOS
1. Extract the ZIP in the Files app.
2. Open `index.html` in Safari (or serve the folder from a local web server if your iOS version does not open local HTML directly).
3. Edit the sample or write your own Luau.
4. Tap **EXPORT .LUA** to save a source file, or **COPY CODE** to copy it.

## Scope and compatibility
This is a source editor/exporter designed for mobile Safari, including iOS 26–27 where supported by the installed Safari version. It does not inject into Roblox, attach to the Roblox process, bypass platform protections, or execute code in the Roblox client. Roblox Studio is the supported environment for testing scripts in experiences you own or are authorized to edit. Roblox Studio itself is not available as a native iOS development environment.

## Security
The editor runs locally in the browser and does not transmit your source code to a server. Avoid putting credentials or private tokens in scripts.
